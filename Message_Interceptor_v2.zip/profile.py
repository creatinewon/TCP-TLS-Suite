"""Portable, data-only profiles. No Python/JavaScript is evaluated from profiles."""
from __future__ import annotations
from copy import deepcopy
import json
from pathlib import Path
import re

BASE = Path(__file__).resolve().parent


def validate(data):
    p=deepcopy(data)
    if not isinstance(p,dict) or p.get('schema_version')!=2:
        raise ValueError('schema_version은 2여야 합니다.')
    for section in ('target','runtime','connection','settings'):
        if not isinstance(p.get(section,{}),dict):raise ValueError(section+'는 객체여야 합니다.')
        p.setdefault(section,{})
    t=p['target']; package=t.get('package','')
    if not isinstance(package,str) or not re.fullmatch(r'[A-Za-z_]\w*(?:\.[A-Za-z_]\w*)+',package):
        raise ValueError('Android package를 지정하세요.')
    process=t.setdefault('process_name',package) or package
    if not isinstance(process,str):raise ValueError('process_name은 문자열입니다.')
    if not re.fullmatch(r'[A-Za-z_]\w*(?:\.[A-Za-z_]\w*)+(?::[A-Za-z0-9_.]+)?',process):raise ValueError('process_name 형식이 올바르지 않습니다.')
    if process!=package and not process.startswith(package+':'):
        raise ValueError('process_name은 해당 package 또는 package:service여야 합니다.')
    t['process_name']=process
    if t.get('pid') is not None and (type(t['pid']) is not int or t['pid']<=0):raise ValueError('PID는 양의 정수 또는 null입니다.')
    t.setdefault('pid',None);t.setdefault('adb_serial','')
    r=p['runtime'];r.setdefault('python_executable','current');r.setdefault('required_version','');r.setdefault('java_bridge','auto')
    for key in ('python_executable','required_version','java_bridge'):
        if not isinstance(r[key],str):raise ValueError('runtime.'+key+'는 문자열입니다.')
    c=p['connection'];c.setdefault('mode','usb');c.setdefault('device_id','');c.setdefault('endpoint','127.0.0.1:27042');c.setdefault('use_adb',c['mode']=='usb')
    if c['mode'] not in ('usb','device_id','remote'):raise ValueError('connection.mode: usb / device_id / remote')
    if type(c['use_adb']) is not bool:raise ValueError('use_adb는 boolean입니다.')
    if c['mode']=='remote' and not c['use_adb'] and t['pid'] is None:raise ValueError('ADB 없는 remote 연결에는 명시적 PID가 필요합니다.')
    if c['mode']=='device_id' and not c['device_id']:raise ValueError('Frida device_id를 지정하세요.')
    s=p['settings'];s.setdefault('timeout_ms',30000);s.setdefault('max_chars',65536);s.setdefault('commands',['*']);s.setdefault('field_separator','\t')
    if type(s['timeout_ms']) is not int or not 100<=s['timeout_ms']<=120000:raise ValueError('timeout_ms 범위: 100~120000')
    if type(s['max_chars']) is not int or not 1<=s['max_chars']<=1048576:raise ValueError('max_chars 범위: 1~1048576')
    if not isinstance(s['commands'],list) or not all(isinstance(x,str) and x for x in s['commands']):raise ValueError('commands는 문자열 배열입니다.')
    if not isinstance(s['field_separator'],str) or not s['field_separator']:raise ValueError('field_separator를 지정하세요.')
    hooks=p.get('hooks')
    if not isinstance(hooks,list) or not hooks:raise ValueError('하나 이상의 hook을 지정하세요.')
    ids=set();signatures=set()
    for h in hooks:
        if not isinstance(h,dict):raise ValueError('hook은 객체여야 합니다.')
        for key in ('id','class_name','method_name'):
            if not isinstance(h.get(key),str) or not h[key]:raise ValueError('hook.'+key+'를 지정하세요.')
        if h['id'] in ids:raise ValueError('hook ID가 중복됩니다.')
        ids.add(h['id'])
        if h.get('direction') not in ('tx','rx'):raise ValueError('direction: tx / rx')
        if h.get('stage') not in ('argument','return'):raise ValueError('stage: argument / return')
        if h.get('data_type') not in ('string','bytes'):raise ValueError('data_type: string / bytes')
        overload=h.get('overload')
        if not isinstance(overload,list) or not all(isinstance(x,str) and x for x in overload):raise ValueError('overload에 정확한 인자 타입 배열을 지정하세요.')
        if h['stage']=='argument':
            i=h.get('argument_index')
            if type(i) is not int or not 0<=i<len(overload):raise ValueError('argument_index가 overload 범위를 벗어났습니다.')
            expected='java.lang.String' if h['data_type']=='string' else '[B'
            if overload[i]!=expected:raise ValueError('후킹 인자 타입과 data_type이 다릅니다.')
        if h.get('payload_scope')!='complete_message':raise ValueError('payload_scope는 complete_message로 지정하세요. raw read 버퍼를 메시지로 취급하지 않습니다.')
        h.setdefault('enabled',True);h.setdefault('required',True);h.setdefault('stack_filter',[])
        if type(h['enabled']) is not bool or type(h['required']) is not bool:raise ValueError('enabled/required는 boolean입니다.')
        if not isinstance(h['stack_filter'],list) or any(not isinstance(f,dict) or not isinstance(f.get('class_name'),str) or not f['class_name'] or not isinstance(f.get('method_name',''),str) for f in h['stack_filter']):raise ValueError('stack_filter 형식을 확인하세요.')
        signature=(h['class_name'],h['method_name'],tuple(overload))
        if h['enabled'] and signature in signatures:raise ValueError('동일 메서드/오버로드를 중복 후킹할 수 없습니다.')
        if h['enabled']:signatures.add(signature)
    if not signatures:raise ValueError('하나 이상의 hook을 활성화하세요.')
    p.setdefault('name',package)
    return p


def load(path):return validate(json.loads(Path(path).read_text(encoding='utf-8-sig')))


def save(path,data):Path(path).write_text(json.dumps(validate(data),ensure_ascii=False,indent=2)+'\n',encoding='utf-8')


def template():return load(BASE/'profiles/android_string_template.json')
