'use strict';
// PROFILE is injected as JSON data by the worker. No profile code is evaluated.
(function () {
  function emit(event,data){send(Object.assign({event:event,time:new Date().toISOString(),pid:Process.id},data||{}));}
  if(typeof Java==='undefined'||!Java.available){emit('fatal',{code:'JAVA_UNAVAILABLE'});return;}
  Java.perform(function(){
    const AT=Java.use('android.app.ActivityThread'),app=AT.currentApplication();
    if(app===null||String(app.getPackageName())!==PROFILE.target.package){emit('fatal',{code:'PACKAGE_MISMATCH'});return;}
    const Thread=Java.use('java.lang.Thread');
    const libc=Process.getModuleByName('libc.so');
    const address=typeof libc.getExportByName==='function'?libc.getExportByName('usleep'):Module.getExportByName('libc.so','usleep');
    const sleep=new NativeFunction(address,'int',['uint'],{scheduling:'cooperative'});
    const pending=new Map(),installed=[];
    let seq=0,stopped=false;
    let config={tx:false,rx:false,timeout_ms:PROFILE.settings.timeout_ms,commands:PROFILE.settings.commands};
    function hex(bytes){let text='';for(let i=0;i<bytes.length;i++)text+=(i?' ':'')+(bytes[i]&255).toString(16).padStart(2,'0');return text;}
    function toBytes(text){const s=text.replace(/\s/g,'');if(s.length%2||!/^[0-9a-f]*$/i.test(s))throw new Error('INVALID_HEX');const values=[];for(let i=0;i<s.length;i+=2){const n=parseInt(s.slice(i,i+2),16);values.push(n>127?n-256:n);}return Java.array('byte',values);}
    function display(value,h){return h.data_type==='bytes'?hex(value):String(value);}
    function value(text,h){return h.data_type==='bytes'?toBytes(text):text;}
    function matches(filters){
      if(!filters.length)return true;
      const frames=Thread.currentThread().getStackTrace();
      return filters.every(f=>{for(let i=0;i<frames.length;i++)if(String(frames[i].getClassName())===f.class_name&&(!f.method_name||String(frames[i].getMethodName())===f.method_name))return true;return false;});
    }
    function decide(entry,p){
      if(entry.done)return;
      entry.done=true;entry.result=entry.original;entry.reason='forward_original';
      if(p.action==='edit'){
        try{
          if(typeof p.text!=='string'||p.text.length>PROFILE.settings.max_chars)throw new Error('SIZE');
          if(entry.h.data_type==='bytes')toBytes(p.text);
          entry.result=p.text;entry.reason='edited';
        }catch(_){entry.reason='invalid_original';}
      }
    }
    function listen(){recv('decision',m=>{const p=m.payload||{},entry=pending.get(p.id);if(entry)decide(entry,p);if(!stopped)listen();});}
    listen();
    function gate(h,input){
      if(stopped||input===null)return input;
      const original=display(input,h),testing=!!h.selftest;
      if(original.length>PROFILE.settings.max_chars){emit('skipped',{hook_id:h.id,reason:'size_limit',chars:original.length});return input;}
      const command=h.data_type==='bytes'?'binary':original.split(PROFILE.settings.field_separator,1)[0];
      if(!testing&&!config.commands.includes('*')&&!config.commands.includes(command))return input;
      const id=++seq,pause=testing?true:config[h.direction];
      const entry={h:h,original:original,result:original,done:false,reason:'monitor'};
      if(pause)pending.set(id,entry);
      const timeout=testing?Number(h.test_timeout||800):config.timeout_ms;
      emit('message',{id:id,direction:h.direction,command:command,hook_id:h.id,text:original,representation:h.data_type==='bytes'?'hex':'text',paused:pause,timeout_ms:timeout,selftest:testing,scenario:h.scenario||null});
      if(pause){const deadline=Date.now()+timeout;while(!entry.done&&!stopped&&Date.now()<deadline)sleep(10000);pending.delete(id);if(!entry.done)entry.reason='timeout_original';}
      emit('complete',{id:id,text:entry.result,modified:entry.result!==original,reason:entry.reason,selftest:testing});
      return entry.result===original?input:value(entry.result,h);
    }
    function install(h){
      const cls=Java.use(h.class_name),o=cls[h.method_name].overload.apply(cls[h.method_name],h.overload);
      const expected=h.data_type==='bytes'?'[B':'java.lang.String';
      if(h.stage==='return'&&o.returnType.className!==expected)throw new Error('RETURN_TYPE_MISMATCH');
      o.implementation=function(){
        const args=Array.prototype.slice.call(arguments);
        if(stopped||!matches(h.stack_filter||[]))return o.apply(this,args);
        try{
          if(h.stage==='argument'){args[h.argument_index]=gate(h,args[h.argument_index]);return o.apply(this,args);}
          return gate(h,o.apply(this,args));
        }catch(e){emit('hook_error',{hook_id:h.id,error_type:e.$className||e.name||'Error'});throw e;}
      };
      installed.push({o:o,id:h.id});return o;
    }
    function restore(){stopped=true;let released=0;pending.forEach(e=>{decide(e,{action:'original'});released++;});installed.forEach(h=>{h.o.implementation=null;});return {restored:installed.length,released:released};}
    try{
      if(!PROFILE.diagnostics_only)PROFILE.hooks.filter(h=>h.enabled).forEach(h=>{
        try{install(h);emit('hook_installed',{hook_id:h.id});}
        catch(e){emit('hook_unavailable',{hook_id:h.id,required:h.required,error_type:e.name||'Error'});if(h.required)throw e;}
      });
      if(!PROFILE.diagnostics_only&&!installed.length)throw new Error('NO_HOOKS_INSTALLED');
    }catch(_){restore();emit('fatal',{code:'HOOK_INSTALL_FAILED'});return;}
    rpc.exports={
      configure:function(c){if(stopped)throw new Error('STOPPED');config={tx:!!c.tx,rx:!!c.rx,timeout_ms:Math.max(100,Math.min(120000,Number(c.timeout_ms)||30000)),commands:c.commands};return config;},
      prepareStop:function(){return new Promise(resolve=>Java.perform(()=>{const result=restore();emit('hooks_restored',result);resolve(result);}));},
      selftest:function(scenario){return new Promise((resolve,reject)=>Java.perform(function(){
        const stamp=Date.now()+(++seq).toString();
        const isBytes=scenario==='argument_bytes'||scenario==='return_bytes';
        const isReturn=scenario.startsWith('return_');
        const type=isBytes?'[B':'java.lang.String';
        const name='org.codex.portablefixture.Echo'+stamp;
        const Echo=Java.registerClass({name:name,methods:{echo:[{returnType:type,argumentTypes:[type],implementation:function(x){return x;}}]}});
        const h={id:'__selftest_'+scenario,class_name:name,method_name:'echo',overload:[type],stage:isReturn?'return':'argument',argument_index:0,data_type:isBytes?'bytes':'string',direction:isReturn?'rx':'tx',stack_filter:[],selftest:true,scenario:scenario,test_timeout:scenario==='timeout'?200:scenario==='hold'?5000:1500};
        let o;
        try{o=install(h);}catch(_){reject(new Error('FIXTURE_INSTALL_FAILED'));return;}
        const Runner=Java.registerClass({name:'org.codex.portablefixture.Runner'+stamp,implements:[Java.use('java.lang.Runnable')],methods:{run:function(){
          try{const input=isBytes?Java.array('byte',[65,66]):'SELFTEST';const output=Echo.$new().echo(input);resolve(isBytes?hex(output):String(output));}
          catch(_){reject(new Error('FIXTURE_CALL_FAILED'));}
          finally{o.implementation=null;const i=installed.findIndex(x=>x.o===o);if(i>=0)installed.splice(i,1);}
        }}});
        Thread.$new(Runner.$new()).start();
      }));}
    };
    emit('ready',{package:PROFILE.target.package,agent_version:typeof Frida!=='undefined'?Frida.version:null,hooks:installed.length,diagnostics_only:!!PROFILE.diagnostics_only});
  });
})();
