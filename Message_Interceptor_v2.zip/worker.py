"""Private JSONL IPC worker; Frida is imported only in the chosen interpreter.
Payloads are written only to the parent GUI pipe. Never run as a traffic logger.
"""
from __future__ import annotations
import argparse
import fnmatch
import importlib.util
import json
from pathlib import Path
import re
import subprocess
import sys
import threading
import uuid

from profile import validate
BASE=Path(__file__).resolve().parent


def bridge_source(frida_version,setting='auto'):
    if setting!='auto':return Path(setting).read_text(encoding='utf-8')
    spec=importlib.util.find_spec('frida_tools')
    if spec and spec.origin:
        path=Path(spec.origin).parent/'bridges/java.js'
        if path.is_file():return path.read_text(encoding='utf-8')
    raise RuntimeError('JAVA_BRIDGE_MISSING: 선택한 환경에 호환 frida-tools 또는 java_bridge 경로가 필요합니다.')


def choose_pid(p):
    t=p['target'];c=p['connection']
    if not c['use_adb']:return t['pid']
    args=['adb']+(['-s',t['adb_serial']] if t['adb_serial'] else [])
    r=subprocess.run(args+['shell','pidof',t['process_name']],capture_output=True,text=True,timeout=8)
    values=[int(x) for x in r.stdout.split() if x.isdigit()]
    if t['pid'] is not None:
        if t['pid'] not in values:raise RuntimeError('PID_SCOPE_MISMATCH')
        return t['pid']
    if len(values)!=1:raise RuntimeError('PID_AMBIGUOUS_OR_APP_NOT_RUNNING')
    return values[0]


class Worker:
    def __init__(self,diagnostics=False):
        self.session=None;self.script=None;self.profile=None;self.ready=threading.Event();self.fatal=None;self.write_lock=threading.Lock();self.session_id=uuid.uuid4().hex;self.diagnostics=diagnostics;self.test_action='edit';self.test_threads=[]
    def emit(self,event,**data):
        with self.write_lock:
            sys.stdout.write(json.dumps({'event':event,'session':self.session_id,**data},ensure_ascii=True)+'\n');sys.stdout.flush()
    def message(self,m,binary):
        if m.get('type')=='error':self.fatal='AGENT_SCRIPT_ERROR';self.ready.set();self.emit('error',code='AGENT_SCRIPT_ERROR');return
        p=m.get('payload')
        if m.get('type')!='send' or not isinstance(p,dict):return
        if p.get('selftest'):
            if p['event']=='message':
                if p.get('scenario')=='hold':self.emit('selftest_waiting');return
                if p.get('scenario')=='timeout':return
                text='43 44' if p.get('representation')=='hex' else 'SELFTEST_OK'
                action='original' if self.test_action=='original' else 'edit'
                self.script.post({'type':'decision','payload':{'id':p['id'],'action':action,'text':text}})
            return
        if p.get('event')=='fatal':self.fatal=p.get('code','AGENT_ERROR');self.ready.set()
        if p.get('event')=='ready':self.agent_info=p;self.ready.set()
        event=p.pop('event');self.emit(event,**p)
    def connect(self,data):
        import frida
        p=validate(data);self.profile=p
        required=p['runtime']['required_version']
        if required and not fnmatch.fnmatchcase(frida.__version__,required):raise RuntimeError('FRIDA_VERSION_MISMATCH: installed='+frida.__version__+' expected='+required)
        c=p['connection']
        if c['mode']=='remote':device=frida.get_device_manager().add_remote_device(c['endpoint'])
        elif c['mode']=='device_id':device=frida.get_device(c['device_id'],timeout=8)
        elif p['target']['adb_serial']:device=frida.get_device(p['target']['adb_serial'],timeout=8)
        else:device=frida.get_usb_device(timeout=8)
        pid=choose_pid(p);session=device.attach(pid);self.session=session
        session.on('detached',lambda reason,crash=None:self.emit('disconnected',reason=str(reason)))
        # Feature detection, rather than a hard-coded Frida major version.
        probe=session.create_script('rpc.exports.probe=()=>typeof Java!=="undefined";')
        try:probe.load();builtin=probe.exports_sync.probe()
        finally:probe.unload()
        prefix='' if builtin else bridge_source(frida.__version__,p['runtime']['java_bridge'])+'\nglobalThis.Java=bridge;\n'
        p['diagnostics_only']=self.diagnostics
        source=prefix+'\nconst PROFILE='+json.dumps(p,ensure_ascii=True)+';\n'+(BASE/'agent.js').read_text(encoding='utf-8')
        self.script=session.create_script(source,name='portable_message_interceptor_v2');self.script.on('message',self.message);self.script.load()
        if not self.ready.wait(10):raise RuntimeError('AGENT_READY_TIMEOUT')
        if self.fatal:raise RuntimeError(self.fatal)
        results={}
        for scenario,expected in [('argument_string','SELFTEST_OK'),('return_string','SELFTEST_OK'),('argument_bytes','43 44'),('return_bytes','43 44'),('timeout','SELFTEST')]:
            result=self.script.exports_sync.selftest(scenario)
            if result!=expected:raise RuntimeError('SELFTEST_FAILED: '+scenario)
            results[scenario]=True
        self.emit('connected',pid=pid,client_version=frida.__version__,agent_version=self.agent_info.get('agent_version'),package=p['target']['package'],selftests=results,diagnostics_only=self.diagnostics)
    def close(self):
        try:
            if self.script:
                result=self.script.exports_sync.prepare_stop();self.emit('restored',**result)
                for thread in self.test_threads:thread.join(timeout=2)
                self.script.unload()
        finally:
            if self.session:
                self.session.detach()
            self.script=None;self.session=None
    def run(self):
        try:
            for line in sys.stdin:
                cmd={}
                try:
                    cmd=json.loads(line);op=cmd.get('op')
                    if op=='connect':self.connect(cmd['profile'])
                    elif op=='configure':self.script.exports_sync.configure(cmd['config'])
                    elif op=='decision':self.script.post({'type':'decision','payload':cmd['payload']})
                    elif op=='probe':
                        import frida
                        self.emit('runtime',version=frida.__version__,python=sys.executable)
                    elif op=='selftest_hold':
                        if not self.diagnostics:raise ValueError('DIAGNOSTICS_ONLY_OPERATION')
                        def hold():
                            try:self.emit('selftest_release_result',original=self.script.exports_sync.selftest('hold')=='SELFTEST')
                            except Exception:self.emit('selftest_release_result',original=False)
                        thread=threading.Thread(target=hold);self.test_threads.append(thread);thread.start()
                    elif op=='disconnect':break
                    else:raise ValueError('UNKNOWN_OPERATION')
                except Exception as e:
                    # Frida exceptions can carry target information; only known own
                    # diagnostics and exception types cross the status channel.
                    text=str(e) if type(e) in (RuntimeError,ValueError) else type(e).__name__
                    self.emit('error',code=text[:350])
                    if cmd.get('op')=='connect':break
        finally:
            try:self.close()
            except Exception as e:self.emit('cleanup_warning',code=type(e).__name__)
            self.emit('worker_stopped')


if __name__=='__main__':
    parser=argparse.ArgumentParser();parser.add_argument('--ipc',action='store_true');parser.add_argument('--diagnostics-only',action='store_true');args=parser.parse_args()
    if not args.ipc:parser.error('이 worker는 GUI 전용 파이프 프로세스입니다. launch.py를 실행하세요.')
    Worker(args.diagnostics_only).run()
