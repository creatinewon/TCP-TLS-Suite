"""Offline profile/runtime/GUI tests. No Frida/device/network required."""
from copy import deepcopy
import io
import json
from pathlib import Path
import queue
import subprocess
import sys
import tkinter as tk
import unittest
from unittest.mock import patch

BASE=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(BASE))
from profile import load,validate,template
from core import Interceptor,visible,unescape,message_from_event,interpreter
from editor import Editor
from worker import choose_pid,bridge_source


class Profiles(unittest.TestCase):
    def test_all_templates_validate(self):
        for p in (BASE/'profiles').glob('*.json'):load(p)
    def test_two_apps_and_frida_versions_are_data(self):
        p=template();p['target']['package']='org.example.second';p['target']['process_name']='org.example.second:service';p['runtime']['required_version']='17.*';p['runtime']['python_executable']='C:/test/venv17/python.exe'
        p=validate(p);self.assertEqual(p['runtime']['required_version'],'17.*');self.assertEqual(p['target']['process_name'],'org.example.second:service')
    def test_other_package_process_rejected(self):
        p=template();p['target']['process_name']='org.example.other'
        with self.assertRaises(ValueError):validate(p)
    def test_adb_process_cannot_contain_shell_syntax(self):
        p=template();p['target']['process_name']=p['target']['package']+':service; echo injected'
        with self.assertRaises(ValueError):validate(p)
    def test_argument_type_mismatch_rejected(self):
        p=template();p['hooks'][0]['data_type']='bytes'
        with self.assertRaises(ValueError):validate(p)
    def test_duplicate_method_hook_rejected(self):
        p=template();p['hooks'][1]=deepcopy(p['hooks'][0]);p['hooks'][1]['id']='different_id'
        with self.assertRaises(ValueError):validate(p)
    def test_raw_stream_scope_rejected(self):
        p=template();p['hooks'][0]['payload_scope']='raw_socket_read'
        with self.assertRaises(ValueError):validate(p)
    def test_remote_requires_explicit_pid_without_adb(self):
        p=template();p['connection'].update(mode='remote',use_adb=False)
        with self.assertRaises(ValueError):validate(p)
        p['target']['pid']=123;self.assertEqual(validate(p)['target']['pid'],123)
    def test_pid_ownership_checked_with_selected_adb_serial(self):
        p=template();p['target'].update(pid=456,adb_serial='SYNTHETIC_SERIAL')
        with patch('worker.subprocess.run',return_value=subprocess.CompletedProcess([],0,'123 456','')) as run:
            self.assertEqual(choose_pid(p),456);self.assertEqual(run.call_args.args[0][:3],['adb','-s','SYNTHETIC_SERIAL'])
        with patch('worker.subprocess.run',return_value=subprocess.CompletedProcess([],0,'123','')):
            with self.assertRaises(RuntimeError):choose_pid(p)
    def test_explicit_java_bridge_is_loaded_as_tool_resource(self):
        with patch('worker.Path.read_text',return_value='var bridge = SYNTHETIC;'):
            self.assertEqual(bridge_source('17.0.0','synthetic_bridge.js'),'var bridge = SYNTHETIC;')


class Transport(unittest.TestCase):
    def test_unicode_and_json_escape_round_trip(self):
        for s in ['SEND\t테스트\r\n','{"literal":"\\n","path":"C:\\tmp"}','\\t\t\f']:
            self.assertEqual(unescape(visible(s)),s)
    def test_hex_edit_validation_and_no_stale_session_edit(self):
        c=Interceptor();c._session_id='new';sent=[];c._send=sent.append
        c.forward(1,'00 ff 41','hex','new');self.assertEqual(sent[0]['payload']['text'],'00 ff 41')
        with self.assertRaises(ValueError):c.forward(1,'0z','hex','new')
        with self.assertRaises(RuntimeError):c.forward(1,'41','hex','old')
    def test_each_connection_spawns_selected_python(self):
        c=Interceptor();p=template();p['runtime']['python_executable']='C:/synthetic/venv/python.exe';c.set_profile(p)
        class Proc:
            stdin=io.StringIO();stdout=io.StringIO();stderr=io.StringIO()
            def poll(self):return None
        with patch('core.subprocess.Popen',return_value=Proc()) as spawn,patch('core.threading.Thread'):
            c.connect();cmd=spawn.call_args.args[0];self.assertEqual(cmd[0],'C:\\synthetic\\venv\\python.exe' if sys.platform=='win32' else 'C:/synthetic/venv/python.exe');self.assertIn('--ipc',cmd)
        self.assertNotIn('frida',__import__('core').__dict__)
    def test_profile_cannot_change_while_worker_running(self):
        c=Interceptor();c._process=object()
        with self.assertRaises(RuntimeError):c.set_profile(template())
    def test_previous_worker_events_are_ignored(self):
        c=Interceptor();c._process=object();c._event({'event':'message','id':1},object());self.assertTrue(c.events.empty())


class GUI(unittest.TestCase):
    def setUp(self):
        self.root=tk.Tk();self.root.withdraw();self.app=Editor(self.root,demo=True)
        self.cancel();self.app.demo_messages();self.app.poll()
    def cancel(self):
        for x in self.root.tk.splitlist(self.root.tk.call('after','info')):self.root.after_cancel(x)
    def tearDown(self):self.app.closed=True;self.cancel();self.root.destroy()
    def test_send_buttons_visible_at_small_height(self):
        self.root.geometry('1000x700');self.root.deiconify();self.root.update()
        for b in (self.app.forward_edited,self.app.forward_original):
            self.assertTrue(b.winfo_ismapped());self.assertLess(b.winfo_rooty()-self.root.winfo_rooty()+b.winfo_height(),700)
    def test_new_profile_updates_filter_and_target(self):
        p=template();p['name']='SECOND';p['settings']['commands']=['ECHO'];self.app.apply_profile(p)
        self.assertEqual(self.app.commands.get(),'ECHO');self.assertIn('SECOND',self.app.profile_label.get())
    def test_pending_edited_send_and_next_pending_selection(self):
        self.app.edited.delete('1.0','end');self.app.edited.insert('1.0','SEND\\tchanged')
        self.app.forward_edited.invoke();self.app.poll();self.assertEqual(self.app.records[3].applied,'SEND\tchanged');self.assertFalse(self.app.records[3].paused)
    def test_duplicate_remote_ids_from_two_sessions_do_not_cross(self):
        for session,body in [('one','FIRST'),('two','SECOND')]:
            self.app.backend.events.put({'event':'message','id':50,'session':session,'time':'2026-01-01T00:00:00Z','direction':'rx','command':body,'text':body,'paused':False})
        self.app.backend.events.put({'event':'complete','id':50,'session':'one','text':'FIRST_APPLIED','reason':'monitor'})
        self.app.poll();self.assertEqual(self.app.records[4].applied,'FIRST_APPLIED');self.assertIsNone(self.app.records[5].applied)
    def test_hex_representation_preserved(self):
        m=message_from_event({'id':9,'session':'s','time':'2026-01-01T00:00:00Z','direction':'tx','command':'binary','text':'00 ff','representation':'hex','paused':True})
        self.assertEqual(m.representation,'hex')


if __name__=='__main__':unittest.main(verbosity=2)
