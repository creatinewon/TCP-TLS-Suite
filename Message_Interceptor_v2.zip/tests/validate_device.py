"""Explicit authorized-device validation; real profile hooks are NOT installed.
Only tool-owned Java fixture methods run. No app codec/login/network call occurs.
"""
import argparse
import json
from pathlib import Path
import queue
import sys
import time
BASE=Path(__file__).resolve().parents[1];sys.path.insert(0,str(BASE))
from core import Interceptor
from profile import load


def main():
    p=argparse.ArgumentParser();p.add_argument('--profile',required=True);p.add_argument('--output',required=True);args=p.parse_args()
    c=Interceptor(load(args.profile),diagnostics=True);events=[];success=None;deadline=time.monotonic()+35
    try:
        c.connect()
        while time.monotonic()<deadline:
            event=c.events.get(timeout=10)
            if event['event']=='connected':success=event;break
            if event['event']=='error':raise RuntimeError(event.get('message','worker error'))
        if success is None:raise RuntimeError('validation timeout')
        c._send({'op':'selftest_hold'})
        while True:
            event=c.events.get(timeout=8)
            if event['event']=='selftest_waiting':break
    finally:
        c.disconnect()
        while not c.events.empty():
            e=c.events.get()
            if e['event'] in ('restored','hooks_restored','cleanup_warning','selftest_release_result'):events.append(e)
    assert success['diagnostics_only'] is True
    assert all(success['selftests'].values())
    assert any(e['event']=='restored' and e['released']>=1 for e in events)
    assert any(e['event']=='selftest_release_result' and e['original'] for e in events)
    out={'client_version':success['client_version'],'agent_version':success['agent_version'],'diagnostics_only':True,'generic_argument_return_string_and_bytes':success['selftests'],'pending_message_released_on_disconnect':True,'real_profile_hooks_installed':False,'application_messages_modified':False,'cleanup':events}
    Path(args.output).write_text(json.dumps(out,indent=2),encoding='utf-8');print(json.dumps(out))


if __name__=='__main__':main()
