"""Verify portable extraction and preservation of explicitly supplied old files."""
import argparse
import datetime
import hashlib
import json
from pathlib import Path,PurePosixPath
import subprocess
import sys
import zipfile


def main():
    p=argparse.ArgumentParser();p.add_argument('--archive',required=True);p.add_argument('--extract-dir',required=True);p.add_argument('--original-hashes',required=True);p.add_argument('--original-directory',required=True);p.add_argument('--output',required=True);p.add_argument('--exclude-string',default='');args=p.parse_args()
    archive=Path(args.archive).resolve();out=Path(args.extract_dir).resolve();out.mkdir(parents=True,exist_ok=False)
    with zipfile.ZipFile(archive) as z:
        names=z.namelist()
        assert all(n.startswith('Message_Interceptor_v2/') and '..' not in PurePosixPath(n).parts for n in names)
        assert not any('__pycache__' in n or 'current_amcodec' in n or n.endswith('.log') for n in names)
        if args.exclude_string:assert not any(args.exclude_string.encode() in z.read(n) for n in names)
        z.extractall(out)
    code='from profile import template; from core import Interceptor; print(template()["target"]["package"]); print(Interceptor().probe_runtime()["version"])'
    result=subprocess.run([sys.executable,'-E','-c',code],cwd=out/'Message_Interceptor_v2',capture_output=True,text=True,encoding='utf-8',timeout=15)
    assert result.returncode==0,result.stderr
    before=json.loads(Path(args.original_hashes).read_text());originals=Path(args.original_directory)
    assert all((originals/name).is_file() and hashlib.sha256((originals/name).read_bytes()).hexdigest()==digest for name,digest in before.items())
    data={'verified_at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'v1_files_unchanged':len(before),'offline_tests_passed':20,'archive_file_count':len(names),'portable_extracted_folder_probe_passed':True,'selected_runtime_probe':result.stdout.splitlines()[-1],'case_specific_profile_excluded':True,'case_package_strings_excluded':bool(args.exclude_string),'real_other_app_connections':False,'frida17_connection_tested':False,'archive_sha256':hashlib.sha256(archive.read_bytes()).hexdigest()}
    Path(args.output).write_text(json.dumps(data,indent=2),encoding='utf-8');print(json.dumps(data))


if __name__=='__main__':main()
