# Message Interceptor v2

앱별 프로필과 독립 Frida worker를 사용하는 로컬 데스크톱 메시지 편집기다. 기존 v1 파일과 실행기는 그대로 사용할 수 있다. v2는 이 폴더만 복사해 다른 작업 폴더에서 사용할 수 있다.

## 실행

`Start_Message_Interceptor_v2.cmd`를 더블클릭하거나 다음 명령을 실행한다.

```powershell
python launch.py
python launch.py --profile path/to/app_profile.json
python launch.py --demo
```

GUI는 Python 3.10 이상과 Tkinter를 사용한다. GUI 프로세스에는 Frida를 import하지 않는다. GUI의 **Python 환경 선택**에서 해당 단말 서버와 호환되는 Frida가 설치된 Python/venv의 python.exe를 선택한다. **Frida 버전 확인**은 대상 앱에 연결하지 않고 그 환경의 버전만 확인한다.

현재 케이스용 프로필은 공유용 폴더 밖의 `03_Dynamic/profiles/current_amcodec_v2.json`에 별도로 있다. 이 프로필을 열면 기존 앱에 맞는 설정을 불러올 수 있다. 같은 앱 프로세스에 연결된 v1은 먼저 연결 해제한 뒤 v2를 연결한다. v1 창과 파일은 삭제할 필요가 없다.

## 새 앱으로 바꾸기

1. `profiles/android_string_template.json` 또는 `android_bytes_template.json`을 **프로필 열기**로 연다.
2. **프로필 설정**에서 package, process, 연결 대상, 메서드/오버로드를 수정한다.
3. **다른 이름 저장**으로 앱별 JSON을 보관한다. 프로필에는 설정만 저장되며 캡처 본문은 저장하지 않는다.
4. 단말에서 승인된 테스트 앱을 직접 실행하고 **앱 연결**을 누른다. 기본 Intercept는 OFF다.
5. 요청/응답 Intercept를 켜고 메시지를 보류한다. 편집 후 상단 **보내기 (편집본)** 또는 Ctrl+Enter를 사용한다. 변경 없이 전달하려면 **원문 보내기**를 누른다.

새 앱의 송수신 메서드를 자동으로 알아내는 도구는 아니다. JADX와 해당 앱의 동작 분석으로 완성 메시지 경계를 찾아 프로필에 지정해야 한다.

## 프로필 필드

| 위치 | 의미 |
|---|---|
| `target.package` | 실제 Android 앱 패키지. agent가 실제 package를 확인한 뒤 후킹 |
| `target.process_name` | package 또는 package:service. 기본값은 package |
| `target.pid` | null이면 ADB로 조회. 지정하면 해당 process의 PID인지 확인 |
| `target.adb_serial` | 여러 단말이 연결됐을 때 ADB 단말 지정 |
| `connection.mode` | usb / device_id / remote |
| `connection.device_id` | Frida 장치 ID를 명시할 때 사용 |
| `connection.endpoint` | 원격 Frida 서버의 host:port. 자동으로 포트나 호스트를 검색하지 않음 |
| `connection.use_adb` | ADB PID 검증 사용. remote에서 false이면 명시적 PID 필요 |
| `runtime.python_executable` | worker를 실행할 Python. current 또는 절대 경로/도구 폴더 기준 상대 경로 |
| `runtime.required_version` | 빈 값은 설치 버전 자동 사용. 16.7.19처럼 정확히 지정하거나 17.*처럼 패턴 지정 |
| `runtime.java_bridge` | auto 또는 신뢰하는 설치된 Java bridge JS 경로 |
| `settings.commands` | 보류/표시할 명령 배열. *는 모두 |
| `settings.field_separator` | 텍스트 명령을 구분하는 필드 구분자. 기본 TAB |
| `settings.timeout_ms` | 기본 대기 시간. 100~120000ms. GUI에서는 1~120초 |
| `settings.max_chars` | 메시지 표시/편집 크기 제한. 초과 메시지는 캡처하지 않고 원문 통과 |

각 hook에는 다음을 지정한다.

```json
{
  "id": "outgoing",
  "direction": "tx",
  "class_name": "com.example.testapp.protocol.Transport",
  "method_name": "sendMessage",
  "overload": ["java.lang.String"],
  "stage": "argument",
  "argument_index": 0,
  "data_type": "string",
  "payload_scope": "complete_message",
  "enabled": true,
  "required": true,
  "stack_filter": []
}
```

- `stage=argument`: 원본 메서드 호출 전에 지정한 인자를 수정한다. 원래 반환값/예외는 유지한다.
- `stage=return`: 원본 메서드 호출 후 반환값을 수정한다. `argument_index`는 필요 없다.
- `data_type=string`: Java String을 텍스트로 편집한다.
- `data_type=bytes`: Java byte[]를 HEX로 편집한다. 예: `00 ff 41 42`. 이 경우 명령 필터 값은 binary 또는 *다. 원문은 인코딩 변환 없이 그대로 유지한다.
- `stack_filter`: 지정한 class_name/method_name이 호출 스택에 모두 존재할 때만 다룬다. method_name을 생략하면 클래스만 비교한다. 송신 로깅용 decode와 실제 수신 decode를 구분할 때 쓴다.
- `required=true`: 설치 실패 시 이미 설치한 후킹을 복원하고 연결을 실패 처리한다. 동일 메서드/오버로드의 중복 지정은 거부한다.

null 입력/반환값은 그대로 통과한다. 예외는 정상 응답으로 바꾸지 않는다. byte[] 훅은 **완성된 단일 메시지 배열**이어야 한다. offset/length 인자를 자동 조정하거나 버퍼의 일부만 잘라 편집하는 기능은 없다. raw socket read/write, TLS record, HTTP chunk 등을 메시지 하나로 가정하지 않는다.

## Frida 버전과 환경 전환

worker는 연결할 때마다 선택한 Python에서 새 프로세스로 시작한다. 16용 worker를 해제한 뒤 17용 Python을 선택해도 GUI에 이전 Frida DLL이 남지 않는다. worker에는 Python -E를 적용하여 부모의 PYTHONPATH/PYTHONHOME이 선택한 환경을 덮어쓰지 않게 한다. 전역 Frida를 자동 업그레이드하거나 단말 서버를 교체하지 않는다.

환경 생성/패키지 설치는 사용자가 별도로 수행한다. 예를 들어 특정 버전을 유지하려면 별도의 venv를 만들고 그 venv에 서버와 호환되는 frida를 설치한 뒤 python.exe를 선택한다. 필요한 버전은 단말 환경에서 검증해야 한다.

Java bridge가 내장된 런타임은 내장 bridge를 사용한다. Java가 없는 런타임은 선택한 Python 환경의 `frida_tools/bridges/java.js`를 찾는다. 없으면 `runtime.java_bridge`로 호환 bridge를 지정한다. 이 JS 파일은 실행 코드이므로 설치된 신뢰 가능한 도구 자원만 지정한다. 임의 APK/분석 결과에 포함된 코드를 bridge로 지정하지 않는다.

현재 실제 단말 검증은 **Frida 16.7.19**에서 수행했다. 17 계열의 별도 Java bridge와 새 Module export API에 대응하는 경로는 구현했지만 실제 17 단말 연결 성공까지 검증한 것은 아니다. 기존 케이스에서 문제가 있었던 17.19.0으로 자동 전환하지 않는다. 프로필의 required_version은 PC client 버전 조건이며 단말 서버 버전을 자동 설치/강제 동기화하는 설정이 아니다.

## 지원 범위와 데이터

Android Java String/byte[]의 완성 메시지 경계를 지원한다. native-only 앱, protobuf 구조체의 자동 해석, 사용자 정의 ClassLoader 탐색, 소켓 재조립, 자동 재전송은 포함하지 않는다. protobuf 등은 앱의 디코딩/인코딩 경계에 맞는 String 또는 완성 byte[] 메서드를 찾아 지정한다. 필요한 클래스가 아직 로드되지 않았으면 해당 흐름을 준비한 뒤 다시 연결한다.

메시지는 GUI와 worker 사이의 전용 메모리 파이프로 전달하며 파일에 자동 저장하지 않는다. worker.py를 터미널 로깅 도구로 실행하지 않는다. 본문과 편집본에는 테스트 비밀정보가 보일 수 있다. 프로필과 bridge/Python 경로는 신뢰하는 설정만 사용한다.

보류 시간이 지나면 단말에서 원문을 자동 통과한다. 연결 해제 시 보류 원문을 통과하고 후킹을 복원한다. 앱/서버 자체 타임아웃은 별도로 남는다. 응답 수정은 앱에 전달되는 값을 바꾸며 서버 인증 수용이나 서버 상태 변경의 증거가 아니다.

## 검증과 휴대용 묶음

```powershell
python tests/test_v2.py
python tests/validate_device.py --profile path/to/authorized_profile.json --output path/to/validation.json
python build_portable.py
```

20개 오프라인 프로필/호스트/GUI 테스트를 통과했다. 기존 허가 단말에서 실제 앱 훅을 설치하지 않는 diagnostics-only 모드로 도구가 만든 Java 메서드를 사용해 String 인자/반환, byte[] 인자/반환 편집, 원문 자동 통과, 보류 중 해제를 검증했다. 실제 다른 앱이나 Frida 17 서버에 접속하는 실험은 하지 않았다.

`build_portable.py`는 소스, 안내서, 일반 예제 프로필, 테스트만 ZIP으로 만든다. 현재 케이스 프로필·분석 로그·캡처 본문·venv·Frida 바이너리는 포함하지 않는다. 다른 폴더로 옮긴 뒤 그 환경의 Python/Frida를 선택해서 사용한다.
