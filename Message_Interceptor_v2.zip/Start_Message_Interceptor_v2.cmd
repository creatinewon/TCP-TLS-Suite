@echo off
start "" /b pythonw "%~dp0launch.py" %*
