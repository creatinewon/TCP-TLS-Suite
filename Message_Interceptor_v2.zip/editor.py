"""Local desktop message viewer/editor. Payloads stay in RAM; no HTTP server."""
from __future__ import annotations

import argparse
from collections import OrderedDict
import queue
import threading
import time
import tkinter as tk
from tkinter import ttk, messagebox, filedialog
import json

from core import DEFAULT_COMMANDS, Interceptor, Message, message_from_event, visible, unescape
from profile import BASE, load, save, validate, template

BG = '#101824'
PANEL = '#182333'
FG = '#e4edf7'
MUTED = '#9cafc5'
ACCENT = '#70dfbd'


class Editor:
    def __init__(self, root, backend=None, demo=False, profile_data=None):
        self.root = root
        self.backend = backend or Interceptor(profile_data)
        self.profile_path = None
        self.profile_label = tk.StringVar(value=self.backend.profile['name'])
        self.records = OrderedDict()
        self.event_keys = {}
        self.next_row = 0
        self.selected = None
        self.closed = False
        self.closing = False
        self.demo = demo
        self.connected = False
        self.busy = False
        self.root.title('Message Interceptor v2 — 프로필 기반 메시지 편집기')
        self.root.geometry('1220x850')
        self.root.minsize(1000, 700)
        self.root.configure(bg=BG)
        self.root.protocol('WM_DELETE_WINDOW', self.close)
        self.tx = tk.BooleanVar(value=False)
        self.rx = tk.BooleanVar(value=False)
        self.escaped = tk.BooleanVar(value=True)
        self.status = tk.StringVar(value='연결 전 · 앱을 단말에서 열고 연결하세요')
        self.detail = tk.StringVar(value='메시지를 선택하세요')
        self.commands = tk.StringVar(value=', '.join(self.backend.profile['settings']['commands']))
        self.timeout = tk.StringVar(value=str(max(1,self.backend.profile['settings']['timeout_ms']//1000)))
        self._build()
        self.root.after(60, self.poll)
        if demo:
            self.root.after(150, self.demo_messages)

    def _build(self):
        style = ttk.Style()
        style.theme_use('clam')
        style.configure('.', background=BG, foreground=FG, font=('Segoe UI', 10))
        style.configure('TFrame', background=BG)
        style.configure('TLabel', background=BG, foreground=FG)
        style.configure('Muted.TLabel', foreground=MUTED)
        style.configure('Title.TLabel', font=('Segoe UI', 23, 'bold'), foreground=ACCENT)
        style.configure('TButton', padding=(13, 7), background=PANEL, foreground=FG)
        style.map('TButton', background=[('active', '#31445a')], foreground=[('disabled', '#64748b')])
        style.configure('Accent.TButton', background='#235f53', foreground='white')
        style.configure('TCheckbutton', background=BG, foreground=FG)
        style.map('TCheckbutton', background=[('active', BG)])
        style.configure('TEntry', fieldbackground=PANEL, foreground=FG, insertcolor=FG)
        style.configure('Treeview', background=PANEL, fieldbackground=PANEL, foreground=FG, rowheight=29, borderwidth=0)
        style.configure('Treeview.Heading', background='#253449', foreground=FG, padding=7)
        style.map('Treeview', background=[('selected', '#28594f')])
        outer = ttk.Frame(self.root, padding=20)
        outer.pack(fill='both', expand=True)
        ttk.Label(outer, text='Message Interceptor v2', style='Title.TLabel').pack(anchor='w')
        ttk.Label(outer, text='앱별 프로필 · 독립 Frida worker · String / byte[] · 자동 저장 없음', style='Muted.TLabel').pack(anchor='w', pady=(2, 8))
        profiles=ttk.Frame(outer)
        profiles.pack(fill='x',pady=(0,8))
        ttk.Button(profiles,text='프로필 열기',command=self.open_profile).pack(side='left')
        ttk.Button(profiles,text='프로필 설정',command=self.profile_settings).pack(side='left',padx=6)
        ttk.Button(profiles,text='다른 이름 저장',command=self.save_profile).pack(side='left')
        ttk.Button(profiles,text='Python 환경 선택',command=self.choose_python).pack(side='left',padx=6)
        ttk.Button(profiles,text='Frida 버전 확인',command=lambda:self.worker(self.backend.probe_runtime)).pack(side='left')
        ttk.Label(profiles,textvariable=self.profile_label,style='Muted.TLabel').pack(side='left',padx=10)
        bar = ttk.Frame(outer)
        bar.pack(fill='x')
        self.connect_btn = ttk.Button(bar, text='앱 연결', command=self.connect, style='Accent.TButton')
        self.connect_btn.pack(side='left')
        self.disconnect_btn = ttk.Button(bar, text='연결 해제', command=self.disconnect, state='disabled')
        self.disconnect_btn.pack(side='left', padx=8)
        ttk.Checkbutton(bar, text='요청 Intercept', variable=self.tx, command=self.configure).pack(side='left', padx=(18, 8))
        ttk.Checkbutton(bar, text='응답 Intercept', variable=self.rx, command=self.configure).pack(side='left', padx=8)
        ttk.Label(bar, text='자동 원문 통과(초)').pack(side='left', padx=(18, 5))
        ttk.Entry(bar, textvariable=self.timeout, width=5).pack(side='left')
        ttk.Button(bar, text='적용', command=self.configure).pack(side='left', padx=6)
        filters = ttk.Frame(outer)
        filters.pack(fill='x', pady=(10, 8))
        ttk.Label(filters, text='표시·보류할 명령').pack(side='left', padx=(0, 8))
        ttk.Entry(filters, textvariable=self.commands).pack(side='left', fill='x', expand=True)
        ttk.Label(filters, text='쉼표 구분 · * 는 전체', style='Muted.TLabel').pack(side='left', padx=10)
        ttk.Button(filters, text='완료 내역 지우기', command=self.clear).pack(side='left')
        ttk.Label(outer, textvariable=self.status, style='Muted.TLabel').pack(anchor='w', pady=(0, 8))
        # Pack the send controls before the expanding panes: they must remain
        # visible even when a small window cannot satisfy Text's requested size.
        controls = ttk.Frame(outer)
        controls.pack(fill='x',pady=(0,10))
        self.forward_edited = ttk.Button(controls,text='보내기 (편집본)',command=lambda:self.forward(True),style='Accent.TButton')
        self.forward_edited.pack(side='left')
        self.forward_original = ttk.Button(controls,text='원문 보내기',command=lambda:self.forward(False))
        self.forward_original.pack(side='left',padx=8)
        self.reset_btn = ttk.Button(controls,text='편집 되돌리기',command=self.render)
        self.reset_btn.pack(side='left')
        ttk.Button(controls,text='다음 보류 선택',command=self.next_pending).pack(side='left',padx=8)
        ttk.Label(controls,text='Ctrl+Enter: 편집본 보내기',style='Muted.TLabel').pack(side='right')
        ttk.Label(outer,text='응답 수정은 앱에 전달하는 값만 변경합니다. 대기 중에는 앱 자체 타임아웃이 발생할 수 있습니다.',style='Muted.TLabel').pack(side='bottom',anchor='w',pady=(10,0))
        pane = ttk.Panedwindow(outer, orient='vertical')
        pane.pack(fill='both', expand=True)
        history = ttk.Frame(pane)
        pane.add(history, weight=2)
        cols = ('id','time','direction','command','status','length')
        self.tree = ttk.Treeview(history, columns=cols, show='headings', selectmode='browse', height=6)
        titles = ['#','단말 시각(UTC)','방향','명령','처리 상태','원문 → 적용 문자 수']
        widths = [45,130,85,190,200,170]
        for c,t,w in zip(cols,titles,widths):
            self.tree.heading(c,text=t)
            self.tree.column(c,width=w,stretch=c in ('command','status'))
        scroll = ttk.Scrollbar(history, orient='vertical', command=self.tree.yview)
        self.tree.configure(yscrollcommand=scroll.set)
        self.tree.pack(side='left',fill='both',expand=True)
        scroll.pack(side='right',fill='y')
        self.tree.tag_configure('held',foreground='#ffd080')
        self.tree.tag_configure('edited',foreground=ACCENT)
        self.tree.bind('<<TreeviewSelect>>', self.select)
        body = ttk.Frame(pane)
        pane.add(body, weight=3)
        toolbar = ttk.Frame(body)
        toolbar.pack(fill='x',pady=(14,8))
        ttk.Label(toolbar,textvariable=self.detail).pack(side='left',fill='x',expand=True)
        ttk.Checkbutton(toolbar,text=r'제어문자 표시 (\t, \n)',variable=self.escaped,command=self.render).pack(side='right')
        texts = ttk.Panedwindow(body,orient='horizontal')
        texts.pack(fill='both',expand=True)
        self.original = self._text_panel(texts, '원문 — 메모리에서만 표시')
        self.edited = self._text_panel(texts, '전달할 메시지 — 보류 중에 편집')
        self.root.bind('<Control-Return>',self.send_shortcut)
        self.edited.bind('<Control-Return>',self.send_shortcut)
        self.render()

    def _text_panel(self, parent, title):
        frame = ttk.Frame(parent)
        parent.add(frame,weight=1)
        ttk.Label(frame,text=title).pack(anchor='w',pady=(0,6))
        text = tk.Text(frame,wrap='none',height=12,bg=PANEL,fg=FG,insertbackground=ACCENT,selectbackground='#345e6b',font=('Consolas',11),relief='flat',padx=12,pady=12,undo=True)
        sy = ttk.Scrollbar(frame,orient='vertical',command=text.yview)
        sx = ttk.Scrollbar(frame,orient='horizontal',command=text.xview)
        text.configure(yscrollcommand=sy.set,xscrollcommand=sx.set)
        sx.pack(side='bottom',fill='x')
        sy.pack(side='right',fill='y')
        text.pack(fill='both',expand=True)
        return text

    def worker(self, fn, result_event=None):
        def run():
            try:
                fn()
                if result_event:
                    self.backend.events.put({'event':result_event})
            except Exception as exc:
                # No payload is ever formatted into an error or persistent log.
                self.backend.events.put({'event':'error','message':f'{type(exc).__name__}: {exc}'})
                if result_event == 'closed':
                    self.backend.events.put({'event':'closed'})
        threading.Thread(target=run,daemon=True).start()

    def apply_profile(self,data,path=None):
        if self.connected or self.busy:
            raise RuntimeError('연결을 해제한 뒤 프로필을 바꾸세요.')
        p=validate(data)
        self.backend.set_profile(p)
        self.profile_path=path
        self.profile_label.set(p['name']+' · '+p['target']['package'])
        self.commands.set(', '.join(p['settings']['commands']))
        self.timeout.set(str(max(1,p['settings']['timeout_ms']//1000)))
        self.status.set('프로필 적용됨 · Python '+p['runtime']['python_executable']+' · Frida '+(p['runtime']['required_version'] or '자동 감지'))

    def open_profile(self):
        path=filedialog.askopenfilename(title='앱 프로필 열기',initialdir=str(BASE/'profiles'),filetypes=[('Profile JSON','*.json')])
        if not path:return
        try:self.apply_profile(load(path),path)
        except Exception as e:messagebox.showerror('프로필',str(e))

    def save_profile(self):
        path=filedialog.asksaveasfilename(title='프로필 저장',defaultextension='.json',filetypes=[('Profile JSON','*.json')])
        if not path:return
        try:
            p=validate(self.backend.profile)
            p['settings']['commands']=[x.strip() for x in self.commands.get().split(',') if x.strip()]
            p['settings']['timeout_ms']=int(self.timeout.get())*1000
            save(path,p);self.profile_path=path
            self.status.set('설정 프로필만 저장했습니다. 메시지 본문은 저장하지 않습니다.')
        except Exception as e:messagebox.showerror('프로필 저장',str(e))

    def choose_python(self):
        path=filedialog.askopenfilename(title='사용할 Python 환경의 python.exe 선택',filetypes=[('Python','python.exe'),('All','*')])
        if not path:return
        try:
            p=validate(self.backend.profile);p['runtime']['python_executable']=path;self.apply_profile(p,self.profile_path)
        except Exception as e:messagebox.showerror('Python 환경',str(e))

    def profile_settings(self):
        if self.connected or self.busy:
            messagebox.showinfo('프로필 설정','연결 해제 후 설정을 바꾸세요.');return
        dialog=tk.Toplevel(self.root);dialog.title('대상 앱 / Frida 환경 / 후킹 프로필');dialog.geometry('900x740')
        box=ttk.Frame(dialog,padding=15);box.pack(fill='both',expand=True)
        ttk.Label(box,text='target: package·process·PID  |  runtime: Python·Frida 버전·Java bridge  |  hooks: 메서드/오버로드/위치').pack(anchor='w',pady=(0,8))
        buttons=ttk.Frame(box);buttons.pack(side='bottom',fill='x',pady=(10,0))
        text=tk.Text(box,bg=PANEL,fg=FG,insertbackground=ACCENT,font=('Consolas',10),wrap='none')
        scrollbar=ttk.Scrollbar(box,command=text.yview);text.configure(yscrollcommand=scrollbar.set);scrollbar.pack(side='right',fill='y');text.pack(fill='both',expand=True)
        text.insert('1.0',json.dumps(self.backend.profile,ensure_ascii=False,indent=2))
        def apply():
            try:self.apply_profile(json.loads(text.get('1.0','end-1c')),self.profile_path);dialog.destroy()
            except Exception as e:messagebox.showerror('프로필 오류',str(e),parent=dialog)
        ttk.Button(buttons,text='적용',command=apply,style='Accent.TButton').pack(side='left')
        ttk.Button(buttons,text='취소',command=dialog.destroy).pack(side='left',padx=8)

    def connect(self):
        if self.busy or self.connected:
            return
        self.busy = True
        self.status.set('테스트 앱 연결 중…')
        self.connect_btn.configure(state='disabled')
        self.worker(self.backend.connect)

    def configure(self):
        if not self.connected:
            return
        try:
            seconds = int(self.timeout.get())
            if not 1 <= seconds <= 120:
                raise ValueError()
        except ValueError:
            messagebox.showerror('대기 시간','1~120초를 입력하세요.')
            return
        commands = [c.strip() for c in self.commands.get().split(',') if c.strip()]
        tx,rx = self.tx.get(),self.rx.get()
        self.worker(lambda:self.backend.configure(tx,rx,commands,seconds*1000))
        for m in self.records.values():
            if m.paused and (not (tx if m.direction=='tx' else rx) or ('*' not in commands and m.command not in commands)):
                self.backend.forward(m.id)
        self.status.set(f'연결됨 · 요청 Intercept {"ON" if tx else "OFF"} · 응답 Intercept {"ON" if rx else "OFF"} · 원문 자동 통과 {seconds}초')

    def disconnect(self):
        self.tx.set(False)
        self.rx.set(False)
        self.status.set('보류 원문 통과 및 후킹 해제 중…')
        self.disconnect_btn.configure(state='disabled')
        self.worker(self.backend.disconnect)

    def row(self,m):
        labels={'monitor':'통과','forward_original':'원문 전달','edited':'편집본 전달','timeout_original':'시간 초과 · 원문 전달','interrupted_original':'중단 · 원문 전달'}
        state='보류 중' if m.paused else labels.get(m.status,m.status)
        return (m.id,m.time[11:23], '요청 →' if m.direction=='tx' else '← 응답',m.command,state,f'{len(m.original)} → {len(m.applied) if m.applied is not None else "대기"}')

    def select(self,event=None):
        values=self.tree.selection()
        self.selected=int(values[0]) if values else None
        self.render()

    def next_pending(self):
        keys=[key for key,m in self.records.items() if m.paused]
        if not keys:
            return False
        index=(keys.index(self.selected)+1)%len(keys) if self.selected in keys else 0
        self.selected=keys[index]
        self.tree.selection_set(str(self.selected))
        self.tree.see(str(self.selected))
        self.render()
        return True

    def send_shortcut(self,event=None):
        self.forward(True)
        return 'break'

    def render(self):
        m=self.records.get(self.selected)
        for widget in (self.original,self.edited):
            widget.configure(state='normal')
            widget.delete('1.0','end')
        if m:
            convert=visible if self.escaped.get() else lambda s:s
            self.original.insert('1.0',convert(m.original))
            self.edited.insert('1.0',convert(m.applied if m.applied is not None else m.original))
            self.detail.set(f'#{m.id}  {m.hook_id} / {m.command} · {m.representation}')
        else:
            self.detail.set('메시지를 선택하세요')
        self.original.configure(state='disabled')
        self.edited.configure(state='normal' if m and m.paused else 'disabled')
        state='normal' if m and m.paused else 'disabled'
        for button in (self.forward_original,self.forward_edited,self.reset_btn):
            button.configure(state=state)

    def forward(self,edit):
        m=self.records.get(self.selected)
        if not m or not m.paused:
            return
        text=self.edited.get('1.0','end-1c') if edit else None
        if edit and self.escaped.get():
            text=unescape(text)
        try:
            if self.demo:
                self.backend.events.put({'event':'complete','id':m.id,'text':text if edit else m.original,'reason':'edited' if edit else 'forward_original','session':m.session})
            else:
                self.backend.forward(m.id,text,m.representation,m.session)
            self.status.set(f'#{m.id} 전달 결정을 보냈습니다. 완료 이벤트 대기 중…')
        except Exception as exc:
            messagebox.showerror('전달 실패',str(exc))

    def clear(self):
        for key,m in list(self.records.items()):
            if not m.paused:
                self.records.pop(key)
                self.tree.delete(str(key))
        if self.selected not in self.records:
            self.selected=None
            self.render()

    def poll(self):
        if self.closed:
            return
        try:
            for _ in range(200):
                p=self.backend.events.get_nowait()
                event=p.get('event')
                if event=='message':
                    m=message_from_event(p)
                    self.next_row+=1
                    key=self.next_row
                    self.event_keys[(m.session,m.id)]=key
                    self.records[key]=m
                    self.tree.insert('', 'end', iid=str(key),values=self.row(m),tags=('held',) if m.paused else ())
                    current=self.records.get(self.selected)
                    if m.paused and (current is None or not current.paused):
                        self.tree.selection_set(str(key));self.tree.see(str(key));self.selected=key;self.render()
                    while len(self.records)>500:
                        old=next((key for key,item in self.records.items() if not item.paused and key!=self.selected),None)
                        if old is None:break
                        self.records.pop(old);self.tree.delete(str(old))
                elif event=='complete':
                    key=self.event_keys.get((p.get('session',''),p['id']))
                    m=self.records.get(key)
                    if m:
                        m.finish(p)
                        self.tree.item(str(key),values=self.row(m),tags=('edited',) if m.applied!=m.original else ())
                        if self.selected==key:
                            if not self.next_pending():self.render()
                elif event=='connected':
                    self.connected=True;self.busy=False
                    self.tx.set(False);self.rx.set(False)
                    self.disconnect_btn.configure(state='normal')
                    self.configure()
                    self.status.set(f'연결됨 · PID {p["pid"]} · Frida {p.get("client_version","?")} · 자체 검증 성공 · Intercept OFF')
                elif event=='disconnected':
                    self.connected=False;self.busy=False
                    self.connect_btn.configure(state='normal');self.disconnect_btn.configure(state='disabled')
                    for key,m in self.records.items():
                        if m.paused:
                            m.paused=False;m.status='연결 종료 · 전달 결과 미확인';self.tree.item(str(key),values=self.row(m))
                    self.render();self.status.set('연결 해제됨')
                elif event in ('error','cleanup_warning'):
                    self.busy=False
                    if not self.connected:self.connect_btn.configure(state='normal')
                    self.status.set(p.get('message','연결 오류'))
                elif event=='restored':
                    self.status.set(f'후킹 {p["restored"]}개 원복 · 보류 {p["released"]}개 원문 통과')
                elif event=='runtime':
                    self.status.set(f'Frida {p["version"]} · Python {p["python"]} · 대상 앱 연결 없이 확인')
                elif event=='closed':
                    self.closed=True;self.root.destroy();return
        except queue.Empty:
            pass
        m=self.records.get(self.selected)
        if m and m.paused:
            remaining=max(0,int(m.deadline-time.monotonic()))
            self.detail.set(f'#{m.id}  {"요청" if m.direction=="tx" else "응답"} / {m.command} · 보류 중 · 원문 자동 통과까지 약 {remaining}초')
        self.root.after(60,self.poll)

    def close(self):
        if self.closing:
            return
        self.closing=True
        self.status.set('보류 원문 통과 후 종료 중…')
        self.worker(self.backend.disconnect,'closed')

    def demo_messages(self):
        self.status.set('데모 · 합성 메시지로만 화면 미리보기 · 단말 연결 없음')
        payloads=[('tx','SEND\tSYNTHETIC',False),('rx','REPLY\tSYNTHETIC',False),('tx','SEND\t{"field":"synthetic_value"}',True)]
        for i,(direction,text,paused) in enumerate(payloads,1):
            self.backend.events.put({'event':'message','id':i,'time':'2026-10-15T00:00:00.000Z','direction':direction,'command':text.split('\t')[0],'text':text,'paused':paused,'timeout_ms':30000})
            if not paused:self.backend.events.put({'event':'complete','id':i,'text':text,'reason':'monitor'})


def main():
    parser=argparse.ArgumentParser()
    parser.add_argument('--demo',action='store_true')
    args=parser.parse_args()
    root=tk.Tk()
    Editor(root,demo=args.demo)
    root.mainloop()


if __name__=='__main__':
    main()
