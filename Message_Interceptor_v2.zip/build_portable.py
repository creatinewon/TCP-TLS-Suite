"""Build a source-only portable ZIP. Never include case profiles or captured data."""
from pathlib import Path
import zipfile
BASE=Path(__file__).resolve().parent


def build(destination=None):
    destination=Path(destination) if destination else BASE.parent/'Message_Interceptor_v2_portable.zip'
    roots=['agent.js','profile.py','core.py','worker.py','editor.py','launch.py','build_portable.py','Start_Message_Interceptor_v2.cmd','README.md']
    files=[BASE/name for name in roots]
    files+=list((BASE/'profiles').glob('*_template.json'))
    files+=list((BASE/'tests').glob('*.py'))
    with zipfile.ZipFile(destination,'w',compression=zipfile.ZIP_DEFLATED) as archive:
        for path in files:
            if not path.is_file():raise FileNotFoundError(path.name)
            archive.write(path,Path('Message_Interceptor_v2')/path.relative_to(BASE))
    return destination


if __name__=='__main__':print(build())
