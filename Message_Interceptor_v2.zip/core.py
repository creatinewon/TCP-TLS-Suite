"""GUI-side transport: standard library only; a fresh worker owns each Frida DLL."""
from __future__ import annotations
from dataclasses import dataclass
import json
from pathlib import Path
import queue
import subprocess
import shutil
import sys
import threading
import time
from profile import validate,template

BASE=Path(__file__).resolve().parent
DEFAULT_COMMANDS=['*']


def visible(text):return text.replace('\\','\\\\').replace('\t','\\t').replace('\r','\\r').replace('\n','\\n').replace('\f','\\f')
def unescape(text):
    result=[];i=0;escapes={'t':'\t','r':'\r','n':'\n','f':'\f','\\':'\\'}
    while i<len(text):
        if text[i]=='\\' and i+1<len(text) and text[i+1] in escapes:result.append(escapes[text[i+1]]);i+=2
        else:result.append(text[i]);i+=1
    return ''.join(result)


def interpreter(value):
    path=sys.executable if not value or value=='current' else value
    p=Path(path)
    if value and value!='current' and not p.is_absolute():
        found=shutil.which(value)
        p=Path(found) if found else BASE/p
    if p.name.lower()=='pythonw.exe' and p.with_name('python.exe').is_file():p=p.with_name('python.exe')
    return str(p)


@dataclass
class Message:
    id:int
    time:str
    direction:str
    command:str
    original:str
    paused:bool
    deadline:float
    session:str=''
    hook_id:str=''
    representation:str='text'
    applied:str|None=None
    status:str='monitor'
    def finish(self,p):self.paused=False;self.applied=p.get('text',self.original);self.status=p.get('reason','forwarded')


def message_from_event(p):
    return Message(p['id'],p['time'],p['direction'],p['command'],p['text'],bool(p.get('paused')),time.monotonic()+p.get('timeout_ms',30000)/1000,p.get('session',''),p.get('hook_id',''),p.get('representation','text'),status='보류 중' if p.get('paused') else '관찰')


class Interceptor:
    def __init__(self,profile=None,diagnostics=False):
        self.profile=validate(profile or template());self.events=queue.Queue(maxsize=2000);self._process=None;self._lock=threading.Lock();self._connected=False;self._closing=False;self.diagnostics=diagnostics;self._session_id=None
    @property
    def connected(self):return self._connected
    def set_profile(self,p):
        if self._process is not None:raise RuntimeError('연결 해제 후 프로필을 변경하세요.')
        self.profile=validate(p)
    def probe_runtime(self):
        flags=getattr(subprocess,'CREATE_NO_WINDOW',0)
        request=json.dumps({'op':'probe'})+'\n'+json.dumps({'op':'disconnect'})+'\n'
        result=subprocess.run([interpreter(self.profile['runtime']['python_executable']),'-E','-X','utf8','-u',str(BASE/'worker.py'),'--ipc'],input=request,capture_output=True,text=True,encoding='utf-8',timeout=12,creationflags=flags,cwd=str(BASE))
        items=[json.loads(s) for s in result.stdout.splitlines() if s.strip()]
        runtime=next((x for x in items if x['event']=='runtime'),None)
        if runtime is None:raise RuntimeError(next((x.get('code') for x in items if x['event']=='error'),'선택한 Python/Frida 환경을 확인할 수 없습니다.'))
        self.events.put(runtime)
        return runtime
    def _send(self,data,process=None):
        proc=process or self._process
        if proc is None or proc.poll() is not None:raise RuntimeError('worker가 연결되지 않았습니다.')
        with self._lock:proc.stdin.write(json.dumps(data,ensure_ascii=True)+'\n');proc.stdin.flush()
    def _event(self,p,proc):
        if proc is not self._process:return
        if p.get('session'):self._session_id=p['session']
        if p['event']=='connected':self._connected=True
        if p['event']=='error':p['message']=p.get('code','Worker error')
        if p['event']=='cleanup_warning':p['message']='정상 해제를 확인하지 못했습니다: '+p.get('code','')
        try:self.events.put_nowait(p)
        except queue.Full:
            if p['event']=='message' and p.get('paused'):self._send({'op':'decision','payload':{'id':p['id'],'action':'original'}},proc)
    def _reader(self,proc):
        try:
            for line in proc.stdout:
                try:self._event(json.loads(line),proc)
                except (ValueError,KeyError):self._event({'event':'error','message':'worker IPC 형식 오류'},proc)
        finally:
            if proc is self._process:
                self._connected=False
                if not self._closing:
                    self._event({'event':'disconnected','reason':'worker 종료'},proc)
                    self._process=None
    def _stderr(self,proc):
        # Drain without echoing any third-party diagnostics or payloads to disk.
        for _ in proc.stderr:pass
    def connect(self):
        if self._process is not None:raise RuntimeError('기존 worker 연결을 먼저 해제하세요.')
        p=validate(self.profile);command=[interpreter(p['runtime']['python_executable']),'-E','-X','utf8','-u',str(BASE/'worker.py'),'--ipc']
        if self.diagnostics:command.append('--diagnostics-only')
        flags=getattr(subprocess,'CREATE_NO_WINDOW',0)
        proc=subprocess.Popen(command,stdin=subprocess.PIPE,stdout=subprocess.PIPE,stderr=subprocess.PIPE,text=True,encoding='utf-8',bufsize=1,creationflags=flags,cwd=str(BASE))
        self._process=proc;self._closing=False
        threading.Thread(target=self._reader,args=(proc,),daemon=True).start()
        threading.Thread(target=self._stderr,args=(proc,),daemon=True).start()
        self._send({'op':'connect','profile':p})
    def configure(self,tx,rx,commands,timeout_ms):
        self._send({'op':'configure','config':{'tx':tx,'rx':rx,'commands':commands,'timeout_ms':timeout_ms}})
    def forward(self,message_id,text=None,representation='text',session=None):
        if session and session!=self._session_id:raise RuntimeError('이전 연결의 메시지입니다.')
        if text is not None:
            if len(text)>self.profile['settings']['max_chars']:raise ValueError('프로필의 메시지 크기 제한을 넘었습니다.')
            if representation=='hex':
                try:bytes.fromhex(text)
                except ValueError:raise ValueError('HEX는 00~ff 바이트를 공백으로 구분해 입력하세요.') from None
        p={'id':message_id,'action':'original' if text is None else 'edit'}
        if text is not None:p['text']=text
        self._send({'op':'decision','payload':p})
    def disconnect(self):
        proc=self._process
        if proc is None:return
        self._closing=True
        try:
            if proc.poll() is None:
                self._send({'op':'disconnect'},proc)
                try:proc.wait(timeout=8)
                except subprocess.TimeoutExpired:
                    # Closing the host only; the agent's bounded gate still returns
                    # the original on expiry. Never kill/restart a target app here.
                    proc.terminate();proc.wait(timeout=4)
                    self.events.put({'event':'cleanup_warning','message':'worker 종료 지연. 대상 앱의 보류 메시지는 제한 시간 후 원문 통과합니다.'})
        finally:
            self._process=None;self._connected=False;self._closing=False
            self.events.put({'event':'disconnected','reason':'연결 해제'})
            for stream in (proc.stdin,proc.stdout,proc.stderr):
                try:stream.close()
                except Exception:pass
