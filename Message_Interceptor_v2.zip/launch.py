"""Portable GUI entry point. It never imports Frida in the GUI process."""
import argparse
import tkinter as tk
from profile import load,template
from editor import Editor


def main():
    p=argparse.ArgumentParser(description='Message Interceptor v2 — Android Java String/byte[]')
    p.add_argument('--profile');p.add_argument('--python',dest='python_executable');p.add_argument('--demo',action='store_true')
    args=p.parse_args()
    data=load(args.profile) if args.profile else template()
    if args.python_executable:data['runtime']['python_executable']=args.python_executable
    root=tk.Tk();app=Editor(root,demo=args.demo,profile_data=data);app.profile_path=args.profile;root.mainloop()


if __name__=='__main__':main()
